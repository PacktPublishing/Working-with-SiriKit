//
//  DataService.swift
//  LEGDAY
//
//  Created by Caleb Stultz on 10/21/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import Foundation
import Intents

class DataService {
    static let instance = DataService()
    
    var startWorkoutIntent: INStartWorkoutIntent?
}
